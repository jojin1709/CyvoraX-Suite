"""
CyvoraX Suite - Repeater module
Send an arbitrary, editable HTTP request and view the raw response,
equivalent to Burp's Repeater tab. Independent of the proxy - talks
directly to the target so you can replay/tweak requests freely.
"""
import socket
import ssl
import re


def send_raw_request(host: str, port: int, raw_request: str, use_tls: bool = True, timeout: float = 10.0) -> str:
    """
    raw_request: full HTTP request text, e.g.
        GET /path HTTP/1.1\r\nHost: example.com\r\n\r\n
    Returns the raw response text (headers + body).
    """
    if "\r\n" not in raw_request:
        raw_request = raw_request.replace("\n", "\r\n")
    if not raw_request.endswith("\r\n\r\n"):
        if raw_request.endswith("\r\n"):
            raw_request += "\r\n"
        else:
            raw_request += "\r\n\r\n"

    sock = socket.create_connection((host, port), timeout=timeout)
    try:
        if use_tls:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            sock = ctx.wrap_socket(sock, server_hostname=host)

        sock.sendall(raw_request.encode())

        chunks = []
        sock.settimeout(timeout)
        try:
            while True:
                chunk = sock.recv(65536)
                if not chunk:
                    break
                chunks.append(chunk)
        except socket.timeout:
            pass
        return b"".join(chunks).decode(errors="replace")
    finally:
        sock.close()


def parse_target_from_request(raw_request: str, default_tls: bool = True):
    """Pull host/port/tls out of a raw request's Host header for convenience."""
    m = re.search(r"^Host:\s*(.+)$", raw_request, re.MULTILINE | re.IGNORECASE)
    if not m:
        raise ValueError("No Host header found in request")
    host_val = m.group(1).strip()
    if ":" in host_val:
        host, port_s = host_val.split(":", 1)
        return host, int(port_s), default_tls
    return host_val, (443 if default_tls else 80), default_tls
