"""
CyvoraX Suite - Active Scanner module
Automated checks run against a target request: reflected XSS, SQLi error
signatures, missing security headers, open redirect, and basic info
disclosure. Each check is a real probe + real detection logic, not a stub.
"""
import re
import time
from dataclasses import dataclass
from typing import List
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from modules.repeater import send_raw_request

SQLI_ERROR_SIGNATURES = [
    "sql syntax", "mysql_fetch", "ora-01756", "sqlite3.operationalerror",
    "unclosed quotation mark", "pg_query", "sqlstate", "syntax error near",
    "warning: mysql", "microsoft ole db provider for odbc drivers"
]

SECURITY_HEADERS = [
    "content-security-policy", "x-frame-options", "x-content-type-options",
    "strict-transport-security", "referrer-policy", "permissions-policy",
]

XSS_MARKER = "cyvoraxXSS1337"


@dataclass
class Finding:
    check: str
    severity: str  # info, low, medium, high
    detail: str
    evidence: str = ""


def _split_headers_body(raw_response: str):
    if "\r\n\r\n" in raw_response:
        head, body = raw_response.split("\r\n\r\n", 1)
    else:
        head, body = raw_response, ""
    return head, body


def check_security_headers(raw_response: str) -> List[Finding]:
    head, _ = _split_headers_body(raw_response)
    head_lower = head.lower()
    findings = []
    for h in SECURITY_HEADERS:
        if h + ":" not in head_lower:
            findings.append(Finding(
                check="Missing Security Header",
                severity="low",
                detail=f"Response is missing the '{h}' header",
            ))
    return findings


def check_sqli_error_signatures(raw_response: str) -> List[Finding]:
    _, body = _split_headers_body(raw_response)
    body_lower = body.lower()
    findings = []
    for sig in SQLI_ERROR_SIGNATURES:
        if sig in body_lower:
            findings.append(Finding(
                check="SQL Injection (error-based)",
                severity="high",
                detail=f"Response body contains a database error signature",
                evidence=sig,
            ))
    return findings


def check_reflected_xss(raw_response: str, marker: str = XSS_MARKER) -> List[Finding]:
    _, body = _split_headers_body(raw_response)
    findings = []
    # only a finding if the marker appears WITHOUT being HTML-encoded
    if marker in body and f"&lt;{marker}" not in body:
        # crude check: was it reflected inside an unescaped context near < or "
        idx = body.find(marker)
        context = body[max(0, idx - 20):idx + len(marker) + 20]
        if "<" in context or ">" in context or '"' in context:
            findings.append(Finding(
                check="Reflected XSS",
                severity="high",
                detail="Injected marker reflected unencoded in response body",
                evidence=context.strip(),
            ))
    return findings


def check_open_redirect(location_header: str, injected_url: str) -> List[Finding]:
    if location_header and injected_url.split("://")[-1] in location_header:
        return [Finding(
            check="Open Redirect",
            severity="medium",
            detail="Location header reflects an attacker-controlled redirect target",
            evidence=location_header,
        )]
    return []


def build_injected_url(url: str, param: str, value: str) -> str:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    qs[param] = [value]
    new_query = urlencode(qs, doseq=True)
    return urlunparse(parsed._replace(query=new_query))


def scan_endpoint(host: str, port: int, path: str, use_tls: bool,
                   params_to_test: List[str] = None, delay_s: float = 0.05) -> List[Finding]:
    """
    Run the full active check suite against one endpoint. path may include
    an existing query string; each param in params_to_test gets probed with
    both an XSS marker and a SQLi quote, one request per probe.
    """
    all_findings: List[Finding] = []

    def send(p):
        req = f"GET {p} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n"
        return send_raw_request(host, port, req, use_tls=use_tls, timeout=10)

    # baseline request - passive checks (headers)
    baseline = send(path)
    all_findings += check_security_headers(baseline)

    if not params_to_test:
        return all_findings

    for param in params_to_test:
        xss_url = build_injected_url(f"http://x{path}", param, XSS_MARKER)
        xss_path = xss_url.split("x", 1)[1] if xss_url.startswith("http://x") else path
        resp = send(urlparse(xss_url).path + "?" + urlparse(xss_url).query)
        all_findings += check_reflected_xss(resp)
        time.sleep(delay_s)

        sqli_url = build_injected_url(f"http://x{path}", param, "'")
        resp2 = send(urlparse(sqli_url).path + "?" + urlparse(sqli_url).query)
        all_findings += check_sqli_error_signatures(resp2)
        time.sleep(delay_s)

    return all_findings
