<div align="center">

# ⬡ CyvoraX Suite Professional

**An Autonomous, Burp-Style Web Security & Penetration Testing Toolkit**

CyvoraX Suite is a high-performance, open-source web security toolkit designed for bug bounty hunters, ethical hackers, and penetration testers. It pairs a high-speed native C scanning core with an `asyncio` + `PyQt6` interface.

---

</div>

> [!TIP]
> **Quick Launch**: On Windows, double-click `dist/CyvoraX.exe` to launch the standalone desktop app directly without installing Python dependencies!

---

## Table of Contents

- [Overview](#overview)
- [Key Features](#key-features)
- [Module Matrix](#module-matrix)
- [Quick Start](#quick-start)
- [Using the Intercepting Proxy](#using-the-intercepting-proxy)
- [Local Verification Testing](#local-verification-testing)
- [Project Architecture](#project-architecture)
- [Current Roadmap](#current-roadmap)
- [License](#license)

---

## Overview

CyvoraX Suite replicates the core workflow of Burp Suite Professional in a standalone desktop application. It covers full MITM HTTP/HTTPS proxy interception, automated parameter fuzzing, token randomness evaluation, active vulnerability scanning (SQLi, XSS, SSRF), and diffing tools.

### Why CyvoraX Suite?

- **Zero Overhead Native Engine**: C-backed multi-threaded socket connect scanner for rapid port discovery.
- **Burp Suite Professional UX**: Built-in dark mode interface with intuitive Request/Response split inspectors and custom action controls.
- **Full MITM Interception**: Dynamic per-host SSL/TLS certificate generation with custom CA integration.
- **Cross-Platform**: Runs on Windows (standalone `.exe`), Linux, and macOS.

---

## Key Features

- **Proxy & Intercept**: `asyncio` MITM HTTP/HTTPS proxy with live request pause, modification, and drop functionality.
- **Intruder Engine**: Multi-mode attack engine (Sniper, Battering Ram, Pitchfork) supporting §marker§ positions and customizable payload lists.
- **Active Scanner**: Automated detection of Reflected XSS, Error-Based SQL Injection, Security Header misconfigurations, and Open Redirects.
- **Sequencer**: Shannon entropy analysis for token randomness (CSRF tokens, session cookies, reset hashes).
- **Decoder / Encoder**: Base64, URL, HTML, Hex, MD5, SHA-1, SHA-256, and JWT decoder transforms.
- **Comparer & Match/Replace**: Text similarity diffing and live regex rewrite rules for request/response bodies and headers.

---

## Module Matrix

| Module | Core Capability | Verification Status |
| :--- | :--- | :--- |
| **Proxy / Intercept** | `asyncio` MITM proxy, custom CA, per-host TLS termination, pause/edit/forward | Verified live 200 OK round-trip with TLS interception |
| **Repeater** | Send & edit raw HTTP requests | Verified with live server request/response cycles |
| **Decoder** | Base64/URL/HTML/Hex, MD5/SHA1/SHA256, JWT | Verified via round-trip assertion tests |
| **Comparer** | Character & line diffing + similarity ratio | Verified via assertion tests |
| **Scanner** | Multi-threaded C port scanner (Winsock2 / POSIX) | Verified live open port detection |
| **Intruder** | Payload injection across §marked§ positions | Verified SQL error (500) and length anomaly flags |
| **Active Scanner** | Reflected XSS, SQLi signatures, missing headers | Verified on live vulnerable test endpoints |
| **Sequencer** | Shannon entropy analysis on token samples | Verified token strength ratings |
| **Match & Replace** | Live regex request/response rewrite engine | Verified via regex assertion tests |

---

## Quick Start

### Option A: Run Pre-Built Executable (Windows)

Simply run the standalone build from your workspace:

```powershell
.\dist\CyvoraX.exe
```

### Option B: Run from Source

#### Prerequisites
- **Python 3.10+**
- **PyQt6 & Cryptography**

```bash
# 1. Clone the repository & install dependencies
git clone https://github.com/your-username/cyvorax-suite.git
cd cyvorax-suite
pip install -r requirements.txt

# 2. (Optional) Compile native C scanner DLL / SO
# Windows:
gcc -O2 -shared -o native/libscanner.dll native/scanner_win.c -lws2_32 -mwindows
# Linux / macOS:
gcc -shared -fPIC -O2 -o native/libscanner.so native/scanner.c -lpthread

# 3. Launch CyvoraX Suite
python main.py
```

---

## Using the Intercepting Proxy

> [!WARNING]
> CyvoraX performs active TLS termination for inspection. Only use CyvoraX against target systems you are authorized to audit.

1. Launch CyvoraX Suite and navigate to the **Proxy** tab (default port: `8080`).
2. Click **Start Proxy**.
3. Configure your web browser or `curl` to proxy traffic through `127.0.0.1:8080`.
4. Import `certs/cyvorax-ca.crt` (generated on first run) into your browser's Trusted Root Certification Authorities store.
5. Toggle **Intercept is on** to capture and edit outgoing requests in real-time.

---

## Local Verification Testing

CyvoraX includes an intentionally vulnerable target server for offline verification and automated testing:

```bash
# 1. Start the local vulnerable test server in the background
python test_target/vuln_server.py &

# 2. Execute test probes against the server
python -c "
from modules.intruder import run_attack, COMMON_PAYLOADS
template = 'GET /user?id=§x§ HTTP/1.1\r\nHost: 127.0.0.1:9091\r\nConnection: close\r\n\r\n'
results = run_attack(template, '127.0.0.1', 9091, use_tls=False, payload_lists=[COMMON_PAYLOADS['sqli_probe']], attack_type='sniper')
for r in results: 
    print(f'Payload: {r.payload:<20} Status: {r.status_code} Length: {r.length}')
"
```

---

## Project Architecture

```text
cyvorax-suite/
├── main.py                     # PyQt6 GUI & Burp-style application interface
├── dist/
│   └── CyvoraX.exe             # Standalone Windows executable
├── modules/
│   ├── proxy_core.py           # asyncio MITM proxy engine & TLS handler
│   ├── certauthority.py        # CA certificate authority generator
│   ├── repeater.py             # Raw HTTP request sender
│   ├── decoder.py              # Encoding/decoding & hashing algorithms
│   ├── comparer.py             # Diff & similarity comparison engine
│   ├── scanner.py              # Multi-threaded port scanner wrapper (C / Python fallback)
│   ├── intruder.py             # Fuzzing & payload injection engine
│   ├── active_scanner.py       # Vulnerability detection checks (XSS, SQLi, Headers)
│   ├── sequencer.py            # Token entropy analysis engine
│   └── match_replace.py        # Live regex rewrite rule engine
├── native/
│   ├── scanner.c               # POSIX C multi-threaded port scanner
│   ├── scanner_win.c           # Windows Winsock2 multi-threaded scanner
│   └── libscanner.dll          # Compiled native library
└── test_target/
    └── vuln_server.py          # Intentionally vulnerable test server
```

---

## Current Roadmap

- [x] Burp Suite Professional UI redesign
- [x] Cross-platform pure Python fallback for native scanner
- [ ] Automated Site Map crawler & spider engine
- [ ] Session handling macros & auto re-login
- [ ] BApp-style plugin extension API
- [ ] CSRF PoC generator & parameter miner

---

## License

Distributed under the MIT License. See `LICENSE` for details.

<div align="center">
  <b>Built for Ethical Hackers & Security Researchers</b>
</div>
