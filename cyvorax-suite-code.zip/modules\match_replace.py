"""
CyvoraX Suite - Match & Replace module
Regex-based rules that auto-rewrite requests/responses as they pass
through the proxy - equivalent to Burp's Match & Replace.
"""
import re
from dataclasses import dataclass


@dataclass
class MatchReplaceRule:
    name: str
    scope: str       # "request" or "response"
    pattern: str      # regex
    replacement: str
    enabled: bool = True

    def compiled(self):
        return re.compile(self.pattern)


class MatchReplaceEngine:
    def __init__(self):
        self.rules = []

    def add_rule(self, rule: MatchReplaceRule):
        self.rules.append(rule)

    def remove_rule(self, name: str):
        self.rules = [r for r in self.rules if r.name != name]

    def apply(self, raw_text: str, scope: str) -> str:
        for rule in self.rules:
            if not rule.enabled or rule.scope != scope:
                continue
            try:
                raw_text = rule.compiled().sub(rule.replacement, raw_text)
            except re.error:
                continue
        return raw_text
