"""
CyvoraX Suite - Decoder module
Encode/decode utilities equivalent to Burp's Decoder tab.
"""
import base64
import urllib.parse
import html
import hashlib
import json


def encode_base64(data: str) -> str:
    return base64.b64encode(data.encode()).decode()


def decode_base64(data: str) -> str:
    padded = data + "=" * (-len(data) % 4)
    return base64.b64decode(padded).decode(errors="replace")


def encode_url(data: str) -> str:
    return urllib.parse.quote(data, safe="")


def decode_url(data: str) -> str:
    return urllib.parse.unquote(data)


def encode_html(data: str) -> str:
    return html.escape(data)


def decode_html(data: str) -> str:
    return html.unescape(data)


def encode_hex(data: str) -> str:
    return data.encode().hex()


def decode_hex(data: str) -> str:
    return bytes.fromhex(data.strip()).decode(errors="replace")


def hash_md5(data: str) -> str:
    return hashlib.md5(data.encode()).hexdigest()


def hash_sha1(data: str) -> str:
    return hashlib.sha1(data.encode()).hexdigest()


def hash_sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


def decode_jwt(token: str) -> str:
    """Decode (not verify) a JWT's header + payload for inspection."""
    parts = token.split(".")
    if len(parts) < 2:
        raise ValueError("Not a valid JWT (expected header.payload.signature)")

    def _b64url_decode(seg):
        padded = seg + "=" * (-len(seg) % 4)
        return base64.urlsafe_b64decode(padded)

    header = json.loads(_b64url_decode(parts[0]))
    payload = json.loads(_b64url_decode(parts[1]))
    return json.dumps({"header": header, "payload": payload}, indent=2)


TRANSFORMS = {
    "Base64 Encode": encode_base64,
    "Base64 Decode": decode_base64,
    "URL Encode": encode_url,
    "URL Decode": decode_url,
    "HTML Encode": encode_html,
    "HTML Decode": decode_html,
    "Hex Encode": encode_hex,
    "Hex Decode": decode_hex,
    "MD5 Hash": hash_md5,
    "SHA1 Hash": hash_sha1,
    "SHA256 Hash": hash_sha256,
    "JWT Decode": decode_jwt,
}
